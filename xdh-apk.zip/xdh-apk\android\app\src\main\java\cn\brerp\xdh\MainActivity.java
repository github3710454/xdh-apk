package cn.brerp.xdh;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
